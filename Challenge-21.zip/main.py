'''Write a program to create an instance of the class and test its abilities'''

class BankAccount:
    def __init__(self, acc_num, acc_holder, initial_balance=0.0):
        self.__acc_num = acc_num
        self.__acc_holder = acc_holder
        self.__balance = initial_balance

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited ${amount}. New balance: ${self.__balance}")
        else:
            print("Invalid deposit amount. Amount must be greater than 0.")

    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            print(f"Withdrew ${amount}. New balance: ${self.__balance}")
        else:
            print("Invalid withdrawal amount or insufficient balance.")

    def display_balance(self):
        print(f"Account Balance for {self.__acc_holder}: ${self.__balance}")

# Testing the BankAccount class
if __name__ == "__main__":
    # Create an instance of the BankAccount class
    acc = BankAccount("123456789", "John Doe", 1000.0)

    # Test deposit and withdrawal functionality
    acc.display_balance()
    acc.deposit(500)
    acc.withdraw(200)
    acc.display_balance()
